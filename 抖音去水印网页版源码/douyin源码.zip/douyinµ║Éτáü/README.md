# douyin

#### 介绍
解析抖音视频的分享链接，获取原始视频，支持在线观看和下载

#### 使用说明
1. python3 manage.py runserver 0.0.0.0:8000
2. [预览](https://dy.helloxjn.com/)

